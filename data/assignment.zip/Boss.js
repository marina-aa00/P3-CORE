/**
 *  @extends Opponent
 */
class Boss extends Opponent {

   /**
     * @param game {Game} La instancia del juego al que pertenece el oponente
     */

     constructor(game){

      super(game);
      this.myImageSrc=BOSS_PICTURE;
      this.myImageDeadSrc= BOSS_PICTURE_DEAD;
      this.speed=BOSS_SPEED;
      this.image.src=this.myImageSrc;
     }

     collide(){
        if (!this.dead) {
            super.collide();
            setTimeout(() => {
                this.game.endGame();
            }, 2000);
            
        }

     }
}